package pe.edu.upeu.sysalmacen.repositorio;

import pe.edu.upeu.sysalmacen.modelo.MediaFile;

public interface IMediaFileRepository extends ICrudGenericoRepository<MediaFile, Long>{
}