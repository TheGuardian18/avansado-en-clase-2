export class Categoria {
  idCategoria: number
  nombre: string
}
