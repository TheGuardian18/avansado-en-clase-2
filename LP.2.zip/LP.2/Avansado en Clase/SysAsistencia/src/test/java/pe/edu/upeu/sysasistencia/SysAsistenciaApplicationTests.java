package pe.edu.upeu.sysasistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysAsistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
